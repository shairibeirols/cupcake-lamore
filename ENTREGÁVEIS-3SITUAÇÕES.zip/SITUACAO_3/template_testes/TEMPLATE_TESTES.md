# Template de Testes - Cupcake Lamore

## Teste de Funcionalidade

### TF-001: Visualizar Catálogo
- **Objetivo:** Verificar exibição de produtos
- **Passos:**
  1. Acessar página inicial
  2. Verificar listagem de produtos
- **Resultado Esperado:** Produtos exibidos corretamente
- **Status:** PASSOU

### TF-002: Adicionar ao Carrinho
- **Objetivo:** Verificar adição de produtos ao carrinho
- **Passos:**
  1. Clicar em produto
  2. Clicar em "Adicionar ao Carrinho"
- **Resultado Esperado:** Produto adicionado
- **Status:** PASSOU

### TF-003: Finalizar Compra
- **Objetivo:** Verificar processo de checkout
- **Passos:**
  1. Acessar carrinho
  2. Clicar em "Finalizar Compra"
  3. Preencher dados
  4. Confirmar
- **Resultado Esperado:** Pedido criado
- **Status:** PASSOU
