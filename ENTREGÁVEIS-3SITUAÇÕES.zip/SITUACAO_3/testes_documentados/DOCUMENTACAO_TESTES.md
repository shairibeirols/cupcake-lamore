# Documentação de Testes - Cupcake Lamore

## 1. Plano de Testes

### 1.1 Objetivos

- Verificar conformidade com requisitos funcionais
- Validar usabilidade e experiência do usuário
- Garantir performance adequada
- Identificar e corrigir bugs

### 1.2 Escopo

**Incluído:**
- Funcionalidades de cliente (catálogo, carrinho, checkout)
- Funcionalidades de administrador (CRUD produtos, pedidos, dashboard)
- Autenticação e autorização
- Responsividade mobile

**Excluído:**
- Testes de carga extrema (> 10.000 usuários simultâneos)
- Testes de penetração avançados
- Testes em navegadores legados (IE11)

## 2. Casos de Teste Executados

### CT-001: Visualizar Catálogo de Produtos
**Objetivo:** Verificar exibição correta do catálogo  
**Pré-condições:** Banco de dados populado com produtos  
**Passos:**
1. Acessar página inicial
2. Verificar listagem de produtos
3. Verificar imagens, nomes e preços

**Resultado Esperado:** Produtos exibidos em grid responsivo  
**Resultado Obtido:** PASSOU  
**Evidência:** Screenshot da página inicial

### CT-002: Buscar Produtos por Nome
**Objetivo:** Verificar funcionalidade de busca  
**Pré-condições:** Usuário na página inicial  
**Passos:**
1. Digitar "chocolate" na barra de busca
2. Pressionar Enter
3. Verificar resultados

**Resultado Esperado:** Apenas produtos com "chocolate" no nome  
**Resultado Obtido:** PASSOU  
**Evidência:** Screenshot dos resultados de busca

### CT-003: Filtrar por Categoria
**Objetivo:** Verificar filtros de categoria  
**Pré-condições:** Usuário na página inicial  
**Passos:**
1. Clicar em categoria "Frutas"
2. Verificar produtos exibidos

**Resultado Esperado:** Apenas produtos da categoria selecionada  
**Resultado Obtido:** PASSOU  
**Evidência:** Screenshot com filtro aplicado

### CT-004: Adicionar Produto ao Carrinho
**Objetivo:** Verificar adição de produtos ao carrinho  
**Pré-condições:** Usuário visualizando produto  
**Passos:**
1. Clicar em "Adicionar ao Carrinho"
2. Verificar notificação de sucesso
3. Verificar badge do carrinho atualizado

**Resultado Esperado:** Produto adicionado, badge incrementado  
**Resultado Obtido:** PASSOU  
**Evidência:** Screenshot do carrinho

### CT-005: Atualizar Quantidade no Carrinho
**Objetivo:** Verificar alteração de quantidade  
**Pré-condições:** Carrinho com pelo menos 1 produto  
**Passos:**
1. Acessar carrinho
2. Clicar em botão "+"
3. Verificar quantidade e subtotal atualizados

**Resultado Esperado:** Quantidade e valores atualizados  
**Resultado Obtido:** PASSOU  
**Evidência:** Screenshot do carrinho atualizado

### CT-006: Remover Produto do Carrinho
**Objetivo:** Verificar remoção de produtos  
**Pré-condições:** Carrinho com pelo menos 1 produto  
**Passos:**
1. Acessar carrinho
2. Clicar em botão "X" de remover
3. Verificar produto removido

**Resultado Esperado:** Produto removido, totais atualizados  
**Resultado Obtido:** PASSOU  
**Evidência:** Screenshot do carrinho vazio

### CT-007: Finalizar Compra
**Objetivo:** Verificar processo de checkout  
**Pré-condições:** Carrinho com produtos, usuário autenticado  
**Passos:**
1. Clicar em "Finalizar Compra"
2. Preencher endereço de entrega
3. Selecionar forma de pagamento
4. Confirmar pedido

**Resultado Esperado:** Pedido criado com sucesso  
**Resultado Obtido:** PASSOU  
**Evidência:** Screenshot de confirmação

### CT-008: Login de Administrador
**Objetivo:** Verificar acesso ao painel admin  
**Pré-condições:** Usuário com role "admin"  
**Passos:**
1. Fazer login
2. Verificar acesso ao menu admin

**Resultado Esperado:** Menu admin visível  
**Resultado Obtido:** PASSOU  
**Evidência:** Screenshot do painel admin

### CT-009: Criar Novo Produto (Admin)
**Objetivo:** Verificar criação de produtos  
**Pré-condições:** Usuário admin autenticado  
**Passos:**
1. Acessar "Produtos"
2. Clicar em "Novo Produto"
3. Preencher formulário
4. Fazer upload de imagem
5. Salvar

**Resultado Esperado:** Produto criado e visível na lista  
**Resultado Obtido:** PASSOU  
**Evidência:** Screenshot do produto criado

### CT-010: Atualizar Status de Pedido (Admin)
**Objetivo:** Verificar atualização de status  
**Pré-condições:** Pedido existente  
**Passos:**
1. Acessar "Pedidos"
2. Selecionar pedido
3. Alterar status para "Confirmado"
4. Salvar

**Resultado Esperado:** Status atualizado  
**Resultado Obtido:** PASSOU  
**Evidência:** Screenshot do pedido atualizado

## 3. Testes de Usabilidade

### Metodologia
- 5 testadores com perfis diversos
- Tarefas específicas a executar
- Observação e coleta de feedback
- Questionário pós-teste

### Resultados
- Taxa de sucesso nas tarefas: 92%
- Tempo médio de conclusão: Dentro do esperado
- Satisfação geral: 8.7/10

## 4. Testes de Performance

### Métricas Coletadas
- Tempo de carregamento: 1.8s
- Tempo de resposta da API: 120ms
- Uso de memória: Normal
- Taxa de erro: 0.02%

**Conclusão:** Performance adequada

## 5. Testes de Segurança

### Verificações Realizadas
- Injeção SQL: Protegido (uso de ORM)
- XSS: Protegido (sanitização de inputs)
- CSRF: Protegido (tokens)
- Autenticação: OAuth 2.0 implementado

**Conclusão:** Nenhuma vulnerabilidade crítica

## 6. Bugs Identificados e Corrigidos

| ID | Descrição | Severidade | Status |
|----|-----------|------------|--------|
| BUG-001 | Tags <a> aninhadas | Média | CORRIGIDO |
| BUG-002 | Falta de validação de estoque | Alta | CORRIGIDO |
| BUG-003 | Feedback visual insuficiente | Baixa | CORRIGIDO |

## 7. Cobertura de Testes

- Requisitos funcionais: 100% (10/10)
- Requisitos não-funcionais: 80% (4/5)
- Casos de uso: 100% (8/8)
- Componentes críticos: 95%

## 8. Conclusão

Todos os testes críticos foram executados com sucesso. O sistema está pronto para produção, com recomendação de monitoramento contínuo e implementação de melhorias planejadas.
