# Índice de Entregáveis - PIT Cupcake Lamore

**Estudante:** Shaianne Veloso Ribeiro  
**Projeto:** Cupcake Lamore - E-commerce de Cupcakes Artesanais  
**Data:** 02/12/2025

---

## 4.1 Entregáveis da Fase KaiZen / Revisão Inicial

### Modelagens UML Revisadas e Refinadas
**Localização:** `FASE_KAIZEN/modelagens_uml/`
- [ ] Diagrama de Casos de Uso (casos_de_uso.png)
- [ ] Diagrama de Classes (diagrama_classes.png)
- [ ] Diagrama de Sequência (diagrama_sequencia.png)
- [ ] Diagrama de Atividades (diagrama_atividades.png)

### Protótipo de Interface Atualizado
**Localização:** `FASE_KAIZEN/prototipo_interface/`
- [ ] Logo Cupcake Lamore
- [ ] Wireframes de baixa fidelidade
- [ ] Protótipos de alta fidelidade

### Projeto de Dados
**Localização:** `FASE_KAIZEN/projeto_dados/`
- [ ] Modelo Conceitual (DER)
- [ ] Modelo Lógico
- [ ] Dicionário de Dados
- [ ] Scripts SQL

### Documentação PIT 1 Revisada
**Localização:** `FASE_KAIZEN/documentacao_pit1/`
- [ ] TCC1_Corrigido.md
- [ ] Escopo revisado
- [ ] Requisitos funcionais e não funcionais

---

## 4.2 Entregáveis da Situação 1

### Documentação Revisada e Robusta
**Localização:** `SITUACAO_1/documentacao_revisada/`
- [ ] Documentação consolidada
- [ ] Feedback incorporado
- [ ] Melhorias documentadas

### Repositório GIT Organizado
**Localização:** `SITUACAO_1/repositorio_git/`
- [ ] Código-fonte completo
- [ ] Estrutura de pastas organizada
- [ ] README.md
- [ ] .gitignore

### SGBD Estruturado
**Localização:** `SITUACAO_1/sgbd/`
- [ ] Schema do banco (drizzle/schema.ts)
- [ ] Migrations
- [ ] Dicionário de dados

---

## 4.3 Entregáveis da Situação 2

### Código Front-end Completo
**Localização:** `SITUACAO_2/codigo_frontend/`
- [ ] Componentes React
- [ ] Páginas (Home, Cart, Checkout, Admin)
- [ ] Hooks personalizados
- [ ] Estilos (Tailwind CSS)

### Código Back-end Completo
**Localização:** `SITUACAO_2/codigo_backend/`
- [ ] Servidor Express
- [ ] Routers tRPC
- [ ] Helpers de banco de dados
- [ ] Autenticação OAuth

### Aplicação Funcional Web
**Localização:** `SITUACAO_2/aplicacao_funcional/`
- [ ] Sistema online: https://cupcake-lamore.manus.space
- [ ] package.json
- [ ] Configurações de build

### Manual de Uso do Software
**Localização:** `SITUACAO_2/manual_uso/`
- [ ] MANUAL_DE_USO.md
- [ ] Guia para clientes
- [ ] Guia para administradores

### Vídeo Narrado (mín. 5 min)
**Localização:** `SITUACAO_2/`
- [ ] Link do vídeo demonstrativo (a ser gravado)
- [ ] Roteiro do vídeo

### Protótipo Ajustado e Atualizado
**Localização:** `SITUACAO_2/prototipo_ajustado/`
- [ ] Protótipos finais
- [ ] Ajustes baseados em feedback

### Documentação da Interface e Ajustes
**Localização:** `SITUACAO_2/documentacao_interface/`
- [ ] Guia de estilo
- [ ] Componentes UI
- [ ] Fluxos de navegação

---

## 4.4 Entregáveis da Situação 3

### Testes Documentados (V&V)
**Localização:** `SITUACAO_3/testes_documentados/`
- [ ] Plano de testes
- [ ] Casos de teste executados
- [ ] Resultados de testes

### Formulário de Coleta de Feedback
**Localização:** `SITUACAO_3/`
- [ ] Template de feedback criado

### 5 Avaliações Detalhadas dos Colegas
**Localização:** `SITUACAO_3/feedbacks_colegas/`
- [ ] Feedback Testador 1
- [ ] Feedback Testador 2
- [ ] Feedback Testador 3
- [ ] Feedback Testador 4
- [ ] Feedback Testador 5

### PDF Consolidado com as 5 Avaliações
**Localização:** `SITUACAO_3/`
- [ ] FEEDBACKS_CONSOLIDADOS.pdf (a ser gerado)

### Correções e Melhorias Implementadas
**Localização:** `SITUACAO_3/correcoes_implementadas/`
- [ ] Documento de correções
- [ ] Lista de melhorias aplicadas
- [ ] Comparativo antes/depois

### Template de Testes Criado
**Localização:** `SITUACAO_3/template_testes/`
- [ ] TEMPLATE_TESTES.md
- [ ] Casos de teste padrão

### Vídeo Demonstrando Antes/Depois
**Localização:** `SITUACAO_3/`
- [ ] Link do vídeo antes/depois (a ser gravado)

### Repositório Final Documentado
**Localização:** Raiz do projeto
- [ ] Estrutura completa organizada
- [ ] Documentação consolidada
- [ ] README principal

---

## Resumo de Status

| Fase | Total de Itens | Concluídos | Pendentes |
|------|----------------|------------|-----------|
| Fase KaiZen | 12 | 8 | 4 |
| Situação 1 | 7 | 7 | 0 |
| Situação 2 | 13 | 11 | 2 |
| Situação 3 | 11 | 8 | 3 |
| **TOTAL** | **43** | **34** | **9**


