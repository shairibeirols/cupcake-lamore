# TCC1 Corrigido - Cupcake Lamore

## 1. Introdução
O projeto Cupcake Lamore visa desenvolver uma plataforma de e-commerce completa.

## 2. Tecnologias
- Front-end: React 19, TypeScript
- Back-end: Node.js, Express, tRPC
- Banco: MySQL
