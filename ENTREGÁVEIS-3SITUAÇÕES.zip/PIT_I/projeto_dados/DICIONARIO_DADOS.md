# Dicionário de Dados - Cupcake Lamore

## Tabela: users

| Campo | Tipo | Tamanho | Nulo | Padrão | Descrição |
|-------|------|---------|------|--------|-----------|
| id | INT | - | NÃO | AUTO | Identificador único do usuário |
| openId | VARCHAR | 64 | NÃO | - | ID OAuth do Manus |
| name | TEXT | - | SIM | NULL | Nome completo do usuário |
| email | VARCHAR | 320 | SIM | NULL | Endereço de e-mail |
| loginMethod | VARCHAR | 64 | SIM | NULL | Método de autenticação utilizado |
| role | ENUM | - | NÃO | 'user' | Papel do usuário (user/admin) |
| createdAt | TIMESTAMP | - | NÃO | NOW() | Data de criação do registro |
| updatedAt | TIMESTAMP | - | NÃO | NOW() | Data da última atualização |
| lastSignedIn | TIMESTAMP | - | NÃO | NOW() | Data do último login |

## Tabela: categories

| Campo | Tipo | Tamanho | Nulo | Padrão | Descrição |
|-------|------|---------|------|--------|-----------|
| id | INT | - | NÃO | AUTO | Identificador único da categoria |
| name | VARCHAR | 100 | NÃO | - | Nome da categoria |
| description | TEXT | - | SIM | NULL | Descrição detalhada |
| createdAt | TIMESTAMP | - | NÃO | NOW() | Data de criação |

## Tabela: products

| Campo | Tipo | Tamanho | Nulo | Padrão | Descrição |
|-------|------|---------|------|--------|-----------|
| id | INT | - | NÃO | AUTO | Identificador único do produto |
| name | VARCHAR | 200 | NÃO | - | Nome do produto |
| description | TEXT | - | SIM | NULL | Descrição detalhada |
| price | DECIMAL | 10,2 | NÃO | - | Preço unitário em reais |
| stock | INT | - | NÃO | 0 | Quantidade em estoque |
| categoryId | INT | - | SIM | NULL | Referência à categoria |
| imageUrl | VARCHAR | 500 | SIM | NULL | URL da imagem do produto |
| createdAt | TIMESTAMP | - | NÃO | NOW() | Data de criação |
| updatedAt | TIMESTAMP | - | NÃO | NOW() | Data da última atualização |

## Tabela: addresses

| Campo | Tipo | Tamanho | Nulo | Padrão | Descrição |
|-------|------|---------|------|--------|-----------|
| id | INT | - | NÃO | AUTO | Identificador único do endereço |
| userId | INT | - | NÃO | - | Referência ao usuário |
| street | VARCHAR | 255 | NÃO | - | Nome da rua |
| number | VARCHAR | 20 | SIM | NULL | Número do imóvel |
| complement | VARCHAR | 100 | SIM | NULL | Complemento |
| neighborhood | VARCHAR | 100 | SIM | NULL | Bairro |
| city | VARCHAR | 100 | NÃO | - | Cidade |
| state | VARCHAR | 2 | NÃO | - | Sigla do estado (UF) |
| zipCode | VARCHAR | 9 | NÃO | - | CEP (formato: 00000-000) |
| createdAt | TIMESTAMP | - | NÃO | NOW() | Data de criação |

## Tabela: orders

| Campo | Tipo | Tamanho | Nulo | Padrão | Descrição |
|-------|------|---------|------|--------|-----------|
| id | INT | - | NÃO | AUTO | Identificador único do pedido |
| userId | INT | - | NÃO | - | Referência ao usuário |
| addressId | INT | - | SIM | NULL | Referência ao endereço de entrega |
| totalAmount | DECIMAL | 10,2 | NÃO | - | Valor total do pedido |
| status | ENUM | - | NÃO | 'pending' | Status do pedido |
| paymentMethod | VARCHAR | 50 | SIM | NULL | Forma de pagamento |
| createdAt | TIMESTAMP | - | NÃO | NOW() | Data de criação |
| updatedAt | TIMESTAMP | - | NÃO | NOW() | Data da última atualização |

**Valores possíveis para status:**
- pending: Aguardando confirmação
- confirmed: Confirmado
- preparing: Em preparação
- shipped: Enviado
- delivered: Entregue
- cancelled: Cancelado

## Tabela: orderItems

| Campo | Tipo | Tamanho | Nulo | Padrão | Descrição |
|-------|------|---------|------|--------|-----------|
| id | INT | - | NÃO | AUTO | Identificador único do item |
| orderId | INT | - | NÃO | - | Referência ao pedido |
| productId | INT | - | NÃO | - | Referência ao produto |
| quantity | INT | - | NÃO | - | Quantidade comprada |
| price | DECIMAL | 10,2 | NÃO | - | Preço unitário no momento da compra |
| createdAt | TIMESTAMP | - | NÃO | NOW() | Data de criação |

## Índices e Constraints

### Índices Primários (PRIMARY KEY)
- users(id)
- categories(id)
- products(id)
- addresses(id)
- orders(id)
- orderItems(id)

### Índices Únicos (UNIQUE)
- users(openId)

### Chaves Estrangeiras (FOREIGN KEY)
- products.categoryId → categories.id
- addresses.userId → users.id
- orders.userId → users.id
- orders.addressId → addresses.id
- orderItems.orderId → orders.id (ON DELETE CASCADE)
- orderItems.productId → products.id
