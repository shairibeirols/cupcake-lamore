# Projeto de Dados - Cupcake Lamore

## 1. Modelo Conceitual (DER)

O banco de dados foi modelado seguindo os princípios de normalização, garantindo integridade referencial e minimizando redundâncias.

### Entidades Principais:
- **User (Usuário)**: Armazena dados dos usuários do sistema
- **Product (Produto)**: Catálogo de cupcakes disponíveis
- **Category (Categoria)**: Classificação dos produtos
- **Order (Pedido)**: Registro de compras realizadas
- **OrderItem (Item do Pedido)**: Produtos incluídos em cada pedido
- **Address (Endereço)**: Endereços de entrega dos clientes

### Relacionamentos:
- User 1:N Order (um usuário pode ter vários pedidos)
- User 1:N Address (um usuário pode ter vários endereços)
- Order 1:N OrderItem (um pedido contém vários itens)
- Product 1:N OrderItem (um produto pode estar em vários pedidos)
- Category 1:N Product (uma categoria agrupa vários produtos)

## 2. Modelo Lógico

### Tabela: users
- id (PK, INT, AUTO_INCREMENT)
- openId (VARCHAR(64), UNIQUE, NOT NULL)
- name (TEXT)
- email (VARCHAR(320))
- loginMethod (VARCHAR(64))
- role (ENUM: 'user', 'admin', DEFAULT 'user')
- createdAt (TIMESTAMP, DEFAULT NOW())
- updatedAt (TIMESTAMP, ON UPDATE NOW())
- lastSignedIn (TIMESTAMP)

### Tabela: categories
- id (PK, INT, AUTO_INCREMENT)
- name (VARCHAR(100), NOT NULL)
- description (TEXT)
- createdAt (TIMESTAMP)

### Tabela: products
- id (PK, INT, AUTO_INCREMENT)
- name (VARCHAR(200), NOT NULL)
- description (TEXT)
- price (DECIMAL(10,2), NOT NULL)
- stock (INT, DEFAULT 0)
- categoryId (FK → categories.id)
- imageUrl (VARCHAR(500))
- createdAt (TIMESTAMP)
- updatedAt (TIMESTAMP)

### Tabela: addresses
- id (PK, INT, AUTO_INCREMENT)
- userId (FK → users.id)
- street (VARCHAR(255), NOT NULL)
- number (VARCHAR(20))
- complement (VARCHAR(100))
- neighborhood (VARCHAR(100))
- city (VARCHAR(100), NOT NULL)
- state (VARCHAR(2), NOT NULL)
- zipCode (VARCHAR(9), NOT NULL)
- createdAt (TIMESTAMP)

### Tabela: orders
- id (PK, INT, AUTO_INCREMENT)
- userId (FK → users.id)
- addressId (FK → addresses.id)
- totalAmount (DECIMAL(10,2), NOT NULL)
- status (ENUM: 'pending', 'confirmed', 'preparing', 'shipped', 'delivered', 'cancelled')
- paymentMethod (VARCHAR(50))
- createdAt (TIMESTAMP)
- updatedAt (TIMESTAMP)

### Tabela: orderItems
- id (PK, INT, AUTO_INCREMENT)
- orderId (FK → orders.id, ON DELETE CASCADE)
- productId (FK → products.id)
- quantity (INT, NOT NULL)
- price (DECIMAL(10,2), NOT NULL)
- createdAt (TIMESTAMP)

## 3. Dicionário de Dados

Ver arquivo DICIONARIO_DADOS.md para detalhes completos de cada campo.

## 4. Scripts SQL

Ver pasta sql/ para scripts de criação e população do banco.
