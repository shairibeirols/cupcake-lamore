# Documentação de Interface - Cupcake Lamore

## 1. Guia de Estilo

### 1.1 Paleta de Cores

**Cores Principais:**
- Rosa: #F4A6B8 (botões, destaques, links)
- Azul Claro: #A8D8EA (elementos secundários, ícones)
- Amarelo Pastel: #FFF4B3 (fundos, destaques suaves)

**Cores Neutras:**
- Branco: #FFFFFF (fundo principal)
- Cinza Claro: #F5F5F5 (fundos alternativos)
- Cinza Escuro: #333333 (textos)
- Preto: #000000 (textos principais)

### 1.2 Tipografia

**Fonte Principal:** Inter, sans-serif

**Hierarquia:**
- H1: 2.5rem (40px), font-weight: 700
- H2: 2rem (32px), font-weight: 600
- H3: 1.5rem (24px), font-weight: 600
- Body: 1rem (16px), font-weight: 400
- Small: 0.875rem (14px), font-weight: 400

### 1.3 Espaçamento

**Sistema de Espaçamento (baseado em 4px):**
- xs: 4px
- sm: 8px
- md: 16px
- lg: 24px
- xl: 32px
- 2xl: 48px

### 1.4 Bordas e Sombras

**Raio de Borda:**
- Pequeno: 4px (botões, inputs)
- Médio: 8px (cards)
- Grande: 16px (modais)
- Circular: 50% (avatares, badges)

**Sombras:**
- Suave: 0 2px 4px rgba(0,0,0,0.1)
- Média: 0 4px 8px rgba(0,0,0,0.15)
- Forte: 0 8px 16px rgba(0,0,0,0.2)

## 2. Componentes UI

### 2.1 Botões

**Variantes:**
- Primary: Fundo rosa, texto branco
- Secondary: Outline rosa, texto rosa
- Ghost: Sem fundo, texto rosa

**Estados:**
- Default: Cor normal
- Hover: Cor mais escura
- Active: Cor ainda mais escura
- Disabled: Opacidade 50%, cursor not-allowed

### 2.2 Cards de Produto

**Estrutura:**
- Imagem (aspect-ratio 1:1)
- Nome do produto (font-weight 600)
- Preço (font-size 1.25rem, color rosa)
- Botão "Adicionar ao Carrinho"

**Comportamento:**
- Hover: Elevação (shadow-md)
- Click: Feedback visual

### 2.3 Formulários

**Inputs:**
- Borda cinza clara
- Focus: Borda rosa
- Error: Borda vermelha + mensagem

**Labels:**
- Sempre visíveis
- Font-weight 500
- Margin-bottom 0.5rem

## 3. Layouts

### 3.1 Layout Principal (Cliente)

**Header:**
- Logo à esquerda
- Barra de busca centralizada
- Carrinho à direita

**Sidebar (Filtros):**
- Largura fixa 250px
- Sticky position

**Conteúdo Principal:**
- Grid responsivo de produtos
- Gap 1.5rem

**Footer:**
- Links institucionais
- Informações de contato
- Copyright

### 3.2 Layout Admin

**Sidebar:**
- Largura 280px
- Menu vertical
- Ícones + texto

**Conteúdo:**
- Padding 2rem
- Breadcrumbs no topo
- Título da página

## 4. Responsividade

### 4.1 Breakpoints

- Mobile: < 640px
- Tablet: 640px - 1024px
- Desktop: > 1024px

### 4.2 Adaptações Mobile

**Header:**
- Logo menor
- Menu hambúrguer
- Busca em modal

**Grid de Produtos:**
- 1 coluna em mobile
- 2 colunas em tablet
- 4 colunas em desktop

**Sidebar:**
- Oculta em mobile
- Acessível via drawer

## 5. Interações e Animações

### 5.1 Transições

**Duração Padrão:** 200ms  
**Easing:** cubic-bezier(0.4, 0, 0.2, 1)

**Elementos Animados:**
- Hover em botões
- Abertura de modais
- Transição de páginas
- Feedback de ações

### 5.2 Loading States

**Skeleton:**
- Usado durante carregamento de produtos
- Animação de pulse

**Spinner:**
- Usado em botões durante ações
- Tamanho proporcional ao botão

## 6. Acessibilidade

### 6.1 Contraste

Todos os textos atendem WCAG AA:
- Texto normal: Contraste mínimo 4.5:1
- Texto grande: Contraste mínimo 3:1

### 6.2 Navegação por Teclado

- Tab: Navega entre elementos focáveis
- Enter/Space: Ativa botões e links
- Esc: Fecha modais e dropdowns

### 6.3 Screen Readers

- Labels descritivos em todos os inputs
- Textos alternativos em imagens
- ARIA labels quando necessário

## 7. Fluxos de Navegação

### 7.1 Fluxo de Compra (Cliente)

1. Página Inicial → Catálogo
2. Catálogo → Detalhes do Produto
3. Adicionar ao Carrinho
4. Carrinho → Checkout
5. Checkout → Confirmação

### 7.2 Fluxo Administrativo

1. Login
2. Dashboard
3. Gerenciar Produtos/Pedidos
4. Ações CRUD
5. Confirmação

## 8. Mensagens e Feedback

### 8.1 Notificações Toast

**Tipos:**
- Success: Fundo verde, ícone de check
- Error: Fundo vermelho, ícone de X
- Warning: Fundo amarelo, ícone de alerta
- Info: Fundo azul, ícone de informação

**Posição:** Top-right  
**Duração:** 3 segundos  
**Dismissível:** Sim

### 8.2 Mensagens de Erro

**Formato:**
- Ícone de erro
- Mensagem clara e objetiva
- Sugestão de ação (quando aplicável)

**Exemplos:**
- "Produto fora de estoque"
- "Preencha todos os campos obrigatórios"
- "Erro ao processar pagamento. Tente novamente."

## 9. Conclusão

Este guia de interface garante consistência visual e funcional em todo o sistema, proporcionando experiência de usuário coesa e profissional.
