# Manual de Uso - Cupcake Lamore

## 1. Introdução

O Cupcake Lamore é um sistema de e-commerce desenvolvido para venda de cupcakes artesanais. Este manual orienta usuários e administradores sobre como utilizar todas as funcionalidades do sistema.

## 2. Acesso ao Sistema

**URL:** https://cupcake-lamore.manus.space

### 2.1 Para Clientes

1. Acesse a URL acima
2. Navegue pelo catálogo sem necessidade de login
3. Para finalizar compras, faça login clicando em "Entrar"
4. Autentique-se usando Google, GitHub ou e-mail

### 2.2 Para Administradores

1. Faça login com conta administrativa
2. Acesse o menu "Admin" no canto superior direito
3. Navegue pelas opções: Dashboard, Produtos, Pedidos

## 3. Funcionalidades para Clientes

### 3.1 Navegar pelo Catálogo

1. Na página inicial, visualize todos os produtos disponíveis
2. Use a barra de busca para encontrar produtos específicos
3. Filtre por categoria usando a sidebar esquerda

### 3.2 Adicionar Produtos ao Carrinho

1. Clique no botão "Adicionar ao Carrinho" no produto desejado
2. Uma notificação confirmará a adição
3. O badge do carrinho será atualizado com a quantidade

### 3.3 Gerenciar Carrinho

1. Clique no ícone do carrinho no header
2. Ajuste quantidades usando os botões + e -
3. Remova itens clicando no X vermelho
4. Visualize o total atualizado em tempo real

### 3.4 Finalizar Compra

1. No carrinho, clique em "Finalizar Compra"
2. Preencha o endereço de entrega:
   - Rua, número, complemento
   - Bairro, cidade, estado
   - CEP
3. Selecione a forma de pagamento (Cartão ou PIX)
4. Revise o resumo do pedido
5. Clique em "Confirmar Pedido"
6. Aguarde a confirmação

### 3.5 Visualizar Histórico de Pedidos

1. Acesse "Meus Pedidos" no menu do usuário
2. Visualize todos os pedidos realizados
3. Clique em um pedido para ver detalhes
4. Acompanhe o status de entrega

## 4. Funcionalidades para Administradores

### 4.1 Dashboard

1. Acesse "Admin" > "Dashboard"
2. Visualize métricas principais:
   - Total de vendas
   - Número de pedidos
   - Produtos em estoque
   - Pedidos pendentes

### 4.2 Gerenciar Produtos

**Listar Produtos:**
1. Acesse "Admin" > "Produtos"
2. Visualize lista completa de produtos
3. Use busca para encontrar produtos específicos

**Criar Novo Produto:**
1. Clique em "Novo Produto"
2. Preencha os campos:
   - Nome
   - Descrição
   - Preço
   - Estoque
   - Categoria
3. Faça upload da imagem
4. Clique em "Salvar"

**Editar Produto:**
1. Clique no ícone de edição (lápis)
2. Modifique os campos desejados
3. Clique em "Salvar"

**Excluir Produto:**
1. Clique no ícone de exclusão (lixeira)
2. Confirme a ação no modal

### 4.3 Gerenciar Pedidos

**Listar Pedidos:**
1. Acesse "Admin" > "Pedidos"
2. Visualize todos os pedidos
3. Filtre por status se necessário

**Atualizar Status:**
1. Clique no pedido desejado
2. Selecione o novo status:
   - Pendente
   - Confirmado
   - Em Preparação
   - Enviado
   - Entregue
   - Cancelado
3. Clique em "Atualizar"

**Visualizar Detalhes:**
1. Clique em um pedido
2. Visualize:
   - Itens do pedido
   - Dados do cliente
   - Endereço de entrega
   - Forma de pagamento
   - Histórico de status

## 5. Dicas e Boas Práticas

### Para Clientes:
- Mantenha seus dados de endereço atualizados
- Verifique o resumo antes de confirmar o pedido
- Acompanhe o status do pedido regularmente
- Entre em contato em caso de dúvidas

### Para Administradores:
- Atualize o estoque regularmente
- Mantenha fotos de produtos de alta qualidade
- Responda pedidos pendentes rapidamente
- Monitore o dashboard diariamente
- Atualize status dos pedidos conforme progresso

## 6. Solução de Problemas

### Problema: Não consigo fazer login
**Solução:** Verifique sua conexão com internet e tente novamente. Se persistir, limpe o cache do navegador.

### Problema: Produto não aparece no catálogo
**Solução:** Verifique se o produto tem estoque disponível e se está ativo no sistema.

### Problema: Erro ao finalizar compra
**Solução:** Verifique se todos os campos obrigatórios foram preenchidos corretamente.

### Problema: Imagem do produto não carrega
**Solução:** Aguarde alguns segundos. Se persistir, recarregue a página.

## 7. Suporte

Para suporte técnico ou dúvidas, entre em contato através de:
- Email: suporte@cupcakelamore.com
- Telefone: (11) 1234-5678
- WhatsApp: (11) 91234-5678

## 8. Requisitos do Sistema

**Navegadores Suportados:**
- Google Chrome (versão 90+)
- Mozilla Firefox (versão 88+)
- Safari (versão 14+)
- Microsoft Edge (versão 90+)

**Dispositivos:**
- Desktop (Windows, macOS, Linux)
- Tablet (iOS, Android)
- Smartphone (iOS, Android)

**Conexão:**
- Recomendado: 5 Mbps ou superior
